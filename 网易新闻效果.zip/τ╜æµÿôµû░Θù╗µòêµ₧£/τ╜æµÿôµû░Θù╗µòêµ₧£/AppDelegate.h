//
//  AppDelegate.h
//  网易新闻效果
//
//  Created by 周松岩 on 16/10/4.
//  Copyright © 2016年 huashan. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;

@end

