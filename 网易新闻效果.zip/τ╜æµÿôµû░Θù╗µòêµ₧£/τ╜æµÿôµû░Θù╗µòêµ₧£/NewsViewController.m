//
//  NewsViewController.m
//  网易新闻效果
//
//  Created by 周松岩 on 16/10/4.
//  Copyright © 2016年 huashan. All rights reserved.
//

#import "NewsViewController.h"

#import "TopLineViewController.h"
#import "HotViewController.h"
#import "SocietyViewController.h"
#import "ScienceViewController.h"
#import "VideoViewController.h"
#import "ReaderViewController.h"

static CGFloat const labelW = 100;
static CGFloat const labelH = 44;
static CGFloat const scaleConst = 1.3;

#define ZSYScreenW [UIScreen mainScreen].bounds.size.width
#define ZSYScreenH [UIScreen mainScreen].bounds.size.height


@interface NewsViewController ()<UIScrollViewDelegate>
@property (weak, nonatomic) IBOutlet UIScrollView *titleScrollView;
@property (weak, nonatomic) IBOutlet UIScrollView *contentScrollView;

/** 存放label */
@property (nonatomic, strong) NSMutableArray<UILabel *> *labels;

//记录下上一次点击的那个label
/** label */
@property (nonatomic, weak) UILabel *selLabel;

@end



@implementation NewsViewController

/** 存放label的数组 */
-(NSMutableArray *)labels
{
    if (!_labels) {
        _labels = [[NSMutableArray alloc] init];
    }
    return _labels;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    //设置子控制器
    [self setUpChildViewController];
    
    //添加自控制器标题
    [self setUpTitleLabel];
    
    //iOS7之后会给导航控制器下所有的UIScrollView顶部添加额外的滚动区域
    self.automaticallyAdjustsScrollViewInsets = NO;
    
    // 设置scrollView
    [self setUpTitleScrollView];
    
    // 设置内容scrollView
    [self setUpContentScrollView];
    
}
// 设置scrollView
- (void)setUpTitleScrollView
{
    // 设置scrollView的滚动区域
    NSUInteger count = self.childViewControllers.count;
    
    self.titleScrollView.contentSize = (CGSize){count * labelW, 0};
    
    // 不显示滚动条
    self.titleScrollView.showsHorizontalScrollIndicator = NO;
}

// 设置内容scrollView
- (void)setUpContentScrollView
{
    // 设置scrollView的滚动区域
    NSUInteger count = self.childViewControllers.count;
    
    self.contentScrollView.contentSize = (CGSize){count * ZSYScreenW, 0};
    
    self.contentScrollView.pagingEnabled = YES;
    
    self.contentScrollView.showsHorizontalScrollIndicator = NO;
    
    self.contentScrollView.bounces = NO;
    
    self.contentScrollView.delegate = self;
}

//添加自控制器标题
- (void)setUpTitleLabel
{
    NSUInteger count = self.childViewControllers.count;
    
    CGFloat labelX = 0;
    CGFloat labelY = 0;
    
    for (int i = 0; i < count; i++) {
        // 拿到自控制器
        UIViewController *vc = self.childViewControllers[i];
        
        //添加label
        UILabel *label = [[UILabel alloc] init];
        labelX = i * labelW;
        
        //设置label标题
        label.text = vc.title;
        label.textAlignment = NSTextAlignmentCenter;
        label.highlightedTextColor = [UIColor redColor];
        
        //设置label尺寸
        label.frame = (CGRect){labelX,labelY,labelW,labelH};
        
        label.userInteractionEnabled = YES;
        
        //给label绑定tag值
        label.tag = i;
        
        //添加手势
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(labelClick:)];
        [label addGestureRecognizer:tap];
        
        // 如果是第0个label，就默认是选中状态的
        if (i == 0) {
            [self labelClick:tap];
        }
        
        [self.labels addObject:label];
        //添加label到滚动条上
        [self.titleScrollView addSubview:label];
    }
}
// label点击事件
- (void)labelClick:(UITapGestureRecognizer *)tap
{
    //拿到点击的是哪个View
    UILabel *selLabel = (UILabel *)tap.view;
    
    //处理label的高亮
    [self selectedLabel:selLabel];
    
    //点击哪个label就移动到哪个界面
    NSInteger index = selLabel.tag;
    
    CGFloat offsetX = index * ZSYScreenW;
    
    self.contentScrollView.contentOffset = (CGPoint){offsetX, 0};
    
    // 显示控制器的View
    [self showVc:index];
    
    //让点击的label居中
    [self labelCenter:selLabel];
}
// 让点击的label居中
- (void)labelCenter:(UILabel *)label
{
    // scrollView的偏移量就是label的中心x值减去屏幕宽度的一半
    CGFloat offsetX = label.center.x - ZSYScreenW * 0.5;
    
    // 最大偏移量就是label的宽度减去屏幕的宽度
    CGFloat maxW = self.titleScrollView.contentSize.width - ZSYScreenW;
//    self.titleScrollView.contentOffset = (CGPoint){offsetX, 0};
    
    if (offsetX < 0){
        offsetX = 0;
    }
    else if (offsetX > maxW){
        offsetX = maxW;
    }
    
    [self.titleScrollView setContentOffset:(CGPoint){offsetX, 0} animated:YES];
}

// 显示控制器的View
- (void)showVc:(NSInteger)index
{
    CGFloat offsetX = index * ZSYScreenW;
    
    UIViewController *vc = self.childViewControllers[index];
    
    // 判断一下VC的View有没有被加载过，如果加载过了，就不加载了
    if (vc.isViewLoaded) {
        return;
    }
    
    vc.view.frame = (CGRect){offsetX, 0, self.contentScrollView.bounds.size.width, self.contentScrollView.bounds.size.height};
    
    [self.contentScrollView addSubview:vc.view];
}


// 处理点击label的高亮
- (void)selectedLabel:(UILabel *)label
{
    //点击下一个的时候，让上一个取消高亮
    _selLabel.highlighted = NO;
    
    //取消形变
    _selLabel.transform = CGAffineTransformIdentity;
    
    //恢复默认颜色
    _selLabel.textColor = [UIColor blackColor];
    
    //点击高亮
    label.highlighted = YES;
    
    label.transform = CGAffineTransformMakeScale(scaleConst, scaleConst);
    
    //记录点击的label，下一次点击的时候让它取消高亮
    _selLabel = label;
}

//设置自控制器
- (void)setUpChildViewController
{
    //头条
    TopLineViewController *top = [[TopLineViewController alloc] init];
    top.title = @"头条";
    [self addChildViewController:top];
    
    //热点
    HotViewController *hot = [[HotViewController alloc] init];
    hot.title = @"热点";
    [self addChildViewController:hot];
    
    //视频
    VideoViewController *video = [[VideoViewController alloc] init];
    video.title = @"视频";
    [self addChildViewController:video];
    
    //社会
    SocietyViewController *society = [[SocietyViewController alloc] init];
    society.title = @"社会";
    [self addChildViewController:society];
    
    //阅读
    ReaderViewController *reader = [[ReaderViewController alloc] init];
    reader.title = @"阅读";
    [self addChildViewController:reader];
    
    //科技
    ScienceViewController *science = [[ScienceViewController alloc] init];
    science.title = @"科技";
    [self addChildViewController:science];
}
#pragma mark- UIScrollViewDelegate

- (void)scrollViewDidScroll:(UIScrollView *)scrollView
{
    CGFloat curPage = scrollView.contentOffset.x / scrollView.bounds.size.width;
    
    //左边label角标
    NSInteger leftIndex = curPage;
 
    //右边label角标
    NSInteger rightIndex = leftIndex + 1;
    
    //左边label
    UILabel *leftLabel = self.labels[leftIndex];
    
    //右边label
    UILabel *rightLabel;
    if (rightIndex < self.labels.count - 1) {
        
        rightLabel = self.labels[rightIndex];
    }
    
    CGFloat scaleRight = curPage - leftIndex;
    CGFloat scaleLeft = 1 - scaleRight;
    
    leftLabel.transform = CGAffineTransformMakeScale(scaleLeft * 0.3 + 1, scaleLeft * 0.3 + 1);
    rightLabel.transform = CGAffineTransformMakeScale(scaleRight * 0.3 + 1, scaleRight * 0.3 + 1);
    
    //滚动的时候改变文字颜色的渐变
    leftLabel.textColor = [UIColor colorWithRed:scaleLeft green:0.0 blue:0.0 alpha:1];
    rightLabel.textColor = [UIColor colorWithRed:scaleRight green:0.0 blue:0.0 alpha:1];

}

- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView
{
    // 获取scrollView的偏移量
    CGFloat offsetX = scrollView.contentOffset.x;
    
    // 当前滚动的角标
    NSInteger index = offsetX / ZSYScreenW;
    
    // 显示控制器的View
    [self showVc:index];
    
    // 根据角标获取到label
    UILabel *label = self.labels[index];
    
    // 设置label高亮
    [self selectedLabel:label];
    
    //让的label居中
    [self labelCenter:label];
}

@end
